#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP_GRADLE="$ROOT/android/app/build.gradle.kts"
MANIFEST="$ROOT/android/app/src/main/AndroidManifest.xml"
KOTLIN_ROOT="$ROOT/android/app/src/main/kotlin"

if [[ ! -f "$APP_GRADLE" ]]; then
  echo "android/ scaffold is missing; generate it with Flutter first." >&2
  exit 1
fi

# Keep the Flutter-generated toolchain, but use a stable app id independent of the Dart package name.
sed -i 's/io\.axymorrsen\.axymorrsen_signer/io.axymorrsen.signer/g' "$APP_GRADLE"
sed -i 's/android:label="axymorrsen_signer"/android:label="AXYMORSEN Signer"/g' "$MANIFEST"

rm -rf "$KOTLIN_ROOT/io/axymorrsen/axymorrsen_signer" "$KOTLIN_ROOT/io/axymorrsen/signer"
mkdir -p "$KOTLIN_ROOT/io/axymorrsen/signer"
cp "$ROOT"/native/android/io/axymorrsen/signer/*.kt "$KOTLIN_ROOT/io/axymorrsen/signer/"

cat >> "$APP_GRADLE" <<'GRADLE'

dependencies {
    implementation("com.android.tools.build:apksig:8.7.3")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
}
GRADLE

echo "Android native signer bridge applied."
