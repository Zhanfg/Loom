enum SignJobState { queued, signing, verified, failed }

class ApkInput {
  const ApkInput({required this.uri, required this.name});

  final String uri;
  final String name;

  Map<String, Object?> toMap() => {'uri': uri, 'name': name};

  factory ApkInput.fromMap(Map<Object?, Object?> map) => ApkInput(
        uri: map['uri']! as String,
        name: map['name']! as String,
      );
}

class SignProgress {
  const SignProgress({
    required this.index,
    required this.total,
    required this.name,
    required this.state,
    this.message,
  });

  final int index;
  final int total;
  final String name;
  final SignJobState state;
  final String? message;

  factory SignProgress.fromMap(Map<Object?, Object?> map) {
    final rawState = map['state']! as String;
    return SignProgress(
      index: map['index']! as int,
      total: map['total']! as int,
      name: map['name']! as String,
      state: SignJobState.values.firstWhere(
        (value) => value.name == rawState,
        orElse: () => SignJobState.failed,
      ),
      message: map['message'] as String?,
    );
  }
}

class SignResult {
  const SignResult({
    required this.name,
    required this.success,
    this.outputUri,
    this.error,
  });

  final String name;
  final bool success;
  final String? outputUri;
  final String? error;

  factory SignResult.fromMap(Map<Object?, Object?> map) => SignResult(
        name: map['name']! as String,
        success: map['success']! as bool,
        outputUri: map['outputUri'] as String?,
        error: map['error'] as String?,
      );
}
