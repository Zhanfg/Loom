class SigningKeyInfo {
  const SigningKeyInfo({
    required this.id,
    required this.alias,
    required this.commonName,
    required this.sha256,
    required this.createdAt,
  });

  final String id;
  final String alias;
  final String commonName;
  final String sha256;
  final DateTime createdAt;

  factory SigningKeyInfo.fromMap(Map<Object?, Object?> map) {
    return SigningKeyInfo(
      id: map['id']! as String,
      alias: map['alias']! as String,
      commonName: map['commonName']! as String,
      sha256: map['sha256']! as String,
      createdAt: DateTime.parse(map['createdAt']! as String),
    );
  }
}
