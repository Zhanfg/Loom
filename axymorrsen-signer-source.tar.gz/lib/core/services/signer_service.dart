import '../models/sign_job.dart';
import '../models/signing_key.dart';

abstract interface class SignerService {
  Stream<SignProgress> get progress;

  Future<List<SigningKeyInfo>> listKeys();

  Future<SigningKeyInfo> generateKey({
    String alias = 'axymorrsen-release',
    String commonName = 'AXYMORSEN',
    String? password,
  });

  Future<List<ApkInput>> pickApks();

  Future<String?> pickOutputDirectory();

  Future<List<SignResult>> signBatch({
    required String keyId,
    required List<ApkInput> apks,
    required String outputDirectoryUri,
  });

  Future<String?> exportKey({
    required String keyId,
    required String outputDirectoryUri,
  });
}
