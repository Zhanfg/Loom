import 'package:flutter/services.dart';

import '../core/models/sign_job.dart';
import '../core/models/signing_key.dart';
import '../core/services/signer_service.dart';

final class NativeSignerService implements SignerService {
  static const _method = MethodChannel('io.axymorrsen.signer/methods');
  static const _events = EventChannel('io.axymorrsen.signer/progress');

  @override
  Stream<SignProgress> get progress => _events
      .receiveBroadcastStream()
      .where((event) => event is Map)
      .map((event) => SignProgress.fromMap(Map<Object?, Object?>.from(event as Map)));

  @override
  Future<List<SigningKeyInfo>> listKeys() async {
    final raw = await _method.invokeListMethod<Object?>('listKeys') ?? const [];
    return raw
        .whereType<Map>()
        .map((value) => SigningKeyInfo.fromMap(Map<Object?, Object?>.from(value)))
        .toList(growable: false);
  }

  @override
  Future<SigningKeyInfo> generateKey({
    String alias = 'axymorrsen-release',
    String commonName = 'AXYMORSEN',
    String? password,
  }) async {
    final raw = await _method.invokeMapMethod<Object?, Object?>(
      'generateKey',
      {'alias': alias, 'commonName': commonName, 'password': password},
    );
    if (raw == null) throw StateError('Native key generation returned no result.');
    return SigningKeyInfo.fromMap(raw);
  }

  @override
  Future<List<ApkInput>> pickApks() async {
    final raw = await _method.invokeListMethod<Object?>('pickApks') ?? const [];
    return raw
        .whereType<Map>()
        .map((value) => ApkInput.fromMap(Map<Object?, Object?>.from(value)))
        .toList(growable: false);
  }

  @override
  Future<String?> pickOutputDirectory() => _method.invokeMethod<String>('pickOutputDirectory');

  @override
  Future<List<SignResult>> signBatch({
    required String keyId,
    required List<ApkInput> apks,
    required String outputDirectoryUri,
  }) async {
    final raw = await _method.invokeListMethod<Object?>('signBatch', {
          'keyId': keyId,
          'apks': apks.map((e) => e.toMap()).toList(growable: false),
          'outputDirectoryUri': outputDirectoryUri,
        }) ??
        const [];
    return raw
        .whereType<Map>()
        .map((value) => SignResult.fromMap(Map<Object?, Object?>.from(value)))
        .toList(growable: false);
  }

  @override
  Future<String?> exportKey({
    required String keyId,
    required String outputDirectoryUri,
  }) {
    return _method.invokeMethod<String>('exportKey', {
      'keyId': keyId,
      'outputDirectoryUri': outputDirectoryUri,
    });
  }
}
