import 'package:flutter/material.dart';

import 'features/home/home_screen.dart';
import 'platform/native_signer_service.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SignerApp());
}

class SignerApp extends StatelessWidget {
  const SignerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AXYMORSEN Signer',
      theme: buildAppTheme(Brightness.light),
      darkTheme: buildAppTheme(Brightness.dark),
      themeMode: ThemeMode.system,
      home: HomeScreen(signer: NativeSignerService()),
    );
  }
}
