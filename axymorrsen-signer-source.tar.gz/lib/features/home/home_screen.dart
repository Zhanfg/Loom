import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/models/sign_job.dart';
import '../../core/models/signing_key.dart';
import '../../core/services/signer_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.signer});

  final SignerService signer;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _alias = TextEditingController(text: 'axymorrsen-release');
  final _commonName = TextEditingController(text: 'AXYMORSEN');
  final _password = TextEditingController();
  final _status = ValueNotifier<String>('Ready');

  List<SigningKeyInfo> _keys = const [];
  List<ApkInput> _apks = const [];
  String? _outputDirectory;
  String? _selectedKeyId;
  bool _customPassword = false;
  bool _busy = false;
  StreamSubscription<SignProgress>? _progressSubscription;

  @override
  void initState() {
    super.initState();
    _refreshKeys();
    _progressSubscription = widget.signer.progress.listen((event) {
      _status.value = '${event.index}/${event.total}  ${event.name}  ·  ${event.state.name}';
    });
  }

  @override
  void dispose() {
    _progressSubscription?.cancel();
    _alias.dispose();
    _commonName.dispose();
    _password.dispose();
    _status.dispose();
    super.dispose();
  }

  Future<void> _refreshKeys() async {
    try {
      final keys = await widget.signer.listKeys();
      if (!mounted) return;
      setState(() {
        _keys = keys;
        if (_selectedKeyId == null || !keys.any((e) => e.id == _selectedKeyId)) {
          _selectedKeyId = keys.isEmpty ? null : keys.first.id;
        }
      });
    } catch (error) {
      _status.value = 'Key list failed: $error';
    }
  }

  Future<void> _run(Future<void> Function() operation) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await operation();
    } catch (error) {
      _status.value = 'Failed: $error';
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _generateKey() => _run(() async {
        _status.value = 'Generating RSA-4096 signing key…';
        final key = await widget.signer.generateKey(
          alias: _alias.text.trim().isEmpty ? 'axymorrsen-release' : _alias.text.trim(),
          commonName: _commonName.text.trim().isEmpty ? 'AXYMORSEN' : _commonName.text.trim(),
          password: _customPassword && _password.text.isNotEmpty ? _password.text : null,
        );
        await _refreshKeys();
        if (!mounted) return;
        setState(() => _selectedKeyId = key.id);
        _status.value = 'Key created · SHA-256 ${key.sha256}';
      });

  Future<void> _pickApks() => _run(() async {
        final files = await widget.signer.pickApks();
        if (!mounted) return;
        setState(() => _apks = files);
        _status.value = files.isEmpty ? 'No APK selected' : '${files.length} APK(s) selected';
      });

  Future<void> _pickOutput() => _run(() async {
        final directory = await widget.signer.pickOutputDirectory();
        if (!mounted) return;
        setState(() => _outputDirectory = directory);
        _status.value = directory == null ? 'Output folder unchanged' : 'Output folder selected';
      });

  Future<void> _sign() => _run(() async {
        final keyId = _selectedKeyId;
        final output = _outputDirectory;
        if (keyId == null) throw StateError('Create or select a signing key first.');
        if (_apks.isEmpty) throw StateError('Select at least one APK.');
        if (output == null) throw StateError('Choose an output folder.');
        _status.value = 'Signing queue started…';
        final results = await widget.signer.signBatch(
          keyId: keyId,
          apks: _apks,
          outputDirectoryUri: output,
        );
        final passed = results.where((e) => e.success).length;
        _status.value = '$passed/${results.length} APK(s) signed and verified';
      });

  Future<void> _exportSelected() => _run(() async {
        final keyId = _selectedKeyId;
        if (keyId == null) throw StateError('Select a key first.');
        final output = _outputDirectory ?? await widget.signer.pickOutputDirectory();
        if (output == null) return;
        if (mounted) setState(() => _outputDirectory = output);
        final uri = await widget.signer.exportKey(keyId: keyId, outputDirectoryUri: output);
        _status.value = uri == null ? 'Export cancelled' : 'Key backup exported';
      });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AXYMORSEN Signer'),
        actions: [
          IconButton(onPressed: _busy ? null : _refreshKeys, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _SectionCard(
              title: 'Signing key',
              subtitle: 'Defaults are ready. Change only what you need.',
              child: Column(
                children: [
                  TextField(controller: _alias, decoration: const InputDecoration(labelText: 'Alias')),
                  const SizedBox(height: 12),
                  TextField(controller: _commonName, decoration: const InputDecoration(labelText: 'Certificate name')),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Use my own PKCS#12 password'),
                    subtitle: const Text('Off = generate a strong random password and protect it with Android Keystore.'),
                    value: _customPassword,
                    onChanged: _busy ? null : (value) => setState(() => _customPassword = value),
                  ),
                  if (_customPassword)
                    TextField(
                      controller: _password,
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'PKCS#12 password'),
                    ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _busy ? null : _generateKey,
                      icon: const Icon(Icons.key),
                      label: const Text('Generate signing key'),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _SectionCard(
              title: 'Batch signing',
              subtitle: 'The queue is intentionally sequential to keep memory, I/O and heat stable.',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  DropdownButtonFormField<String>(
                    value: _selectedKeyId,
                    decoration: const InputDecoration(labelText: 'Signing key'),
                    items: _keys
                        .map((key) => DropdownMenuItem(value: key.id, child: Text('${key.alias} · ${key.sha256.substring(0, 17)}…')))
                        .toList(growable: false),
                    onChanged: _busy ? null : (value) => setState(() => _selectedKeyId = value),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _pickApks,
                    icon: const Icon(Icons.android),
                    label: Text(_apks.isEmpty ? 'Select APKs' : '${_apks.length} APK(s) selected'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _pickOutput,
                    icon: const Icon(Icons.folder_open),
                    label: Text(_outputDirectory == null ? 'Choose output folder' : 'Output folder selected'),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _busy ? null : _sign,
                    icon: const Icon(Icons.verified),
                    label: const Text('Sign and verify'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _SectionCard(
              title: 'Key manager',
              subtitle: '${_keys.length} key(s) stored in the app-private vault.',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  for (final key in _keys)
                    RadioListTile<String>(
                      value: key.id,
                      groupValue: _selectedKeyId,
                      onChanged: _busy ? null : (value) => setState(() => _selectedKeyId = value),
                      title: Text(key.alias),
                      subtitle: Text('CN=${key.commonName}\n${key.sha256}'),
                    ),
                  OutlinedButton.icon(
                    onPressed: _busy || _selectedKeyId == null ? null : _exportSelected,
                    icon: const Icon(Icons.save_alt),
                    label: const Text('Export selected .p12 backup'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            ValueListenableBuilder<String>(
              valueListenable: _status,
              builder: (context, value, _) => Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      if (_busy) ...[
                        const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                        const SizedBox(width: 12),
                      ],
                      Expanded(child: Text(value)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.title, required this.subtitle, required this.child});

  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 16),
            child,
          ],
        ),
      ),
    );
  }
}
