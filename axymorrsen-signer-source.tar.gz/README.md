# AXYMORSEN Signer 1.0.0

Flutter signing workspace designed to keep the UI and task engine reusable across Android, Windows, and macOS.

## Android 1.0.0

- One-tap RSA-4096 / SHA-256 PKCS#12 key generation.
- Random password by default; password is encrypted with an Android Keystore AES-256-GCM master key.
- SAF multi-select for APKs and output folder; no broad storage permission.
- Sequential batch signing to bound RAM, storage I/O, and heat.
- APK Signature Scheme v1/v2/v3 through AOSP `apksig`.
- Every output is verified before export.
- Explicit `.p12` + recovery-password export.

## Build

The repository intentionally does not commit generated Flutter platform folders. CI creates the Android scaffold with the active Flutter stable toolchain and then applies `native/android` through `tool/bootstrap_android.sh`.

```bash
flutter pub get
flutter analyze
flutter test
```

For Android, follow the CI workflow in `.github/workflows/build-android.yml`.

## Security

Never commit exported `.p12`, `.jks`, `.keystore`, password recovery files, API keys, tokens, or other secrets.
