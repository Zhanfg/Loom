# Architecture

AXYMORSEN Signer keeps application workflow separate from platform signing backends.

## Stable cross-platform layer

- `lib/core/models`: immutable task and key metadata.
- `lib/core/services/SignerService`: the platform contract.
- `lib/features`: Flutter UI and orchestration.
- The batch queue is sequential by design: one APK occupies the heavy signing path at a time.

## Android backend

`native/android` implements the same contract through Flutter platform channels.

- RSA-4096 signing keys are generated locally.
- PKCS#12 files stay in app-private storage.
- PKCS#12 passwords are encrypted with an AES-256-GCM key stored in Android Keystore.
- APK input/output uses Storage Access Framework URIs; broad storage permission is not required.
- `apksig` signs with v1/v2/v3 and immediately verifies each output before it is copied to the selected folder.
- Explicit export writes both the `.p12` and its recovery password file. Both are secrets and must be protected.

## Windows/macOS expansion

Do not fork the Flutter application. Implement the existing `io.axymorrsen.signer/methods` contract on each platform, then add installer packaging:

- Windows: native signing backend + MSIX/installer target.
- macOS: native signing backend + `.app`/DMG target.

The UI, task model, queue semantics, validation, and key metadata remain shared Dart code.
