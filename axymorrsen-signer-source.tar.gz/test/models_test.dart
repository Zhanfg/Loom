import 'package:axymorrsen_signer/core/models/sign_job.dart';
import 'package:axymorrsen_signer/core/models/signing_key.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('key metadata round-trip parser keeps identity fields', () {
    final key = SigningKeyInfo.fromMap({
      'id': 'k1',
      'alias': 'release',
      'commonName': 'AXYMORSEN',
      'sha256': 'AA:BB',
      'createdAt': '2026-10-02T00:00:00Z',
    });
    expect(key.id, 'k1');
    expect(key.alias, 'release');
  });

  test('progress maps native state names', () {
    final progress = SignProgress.fromMap({
      'index': 1,
      'total': 2,
      'name': 'app.apk',
      'state': 'verified',
    });
    expect(progress.state, SignJobState.verified);
  });
}
